<?php
$autoload->Bases = array('BasePage');

$autoload->Models = array();

$autoload->Assistants = array();

$autoload->Plugins = array('SocialMedia', 'Gravatar');
