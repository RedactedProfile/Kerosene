<ul id="internal-submenu">
	<li><a href="/admin/cart/products">Products</a>
		<ul class="internal-subsubmenu">
			<a href="/admin/cart/products/add">Add New Product</a>
		</ul>
	</li>
	<li><a href="/admin/cart/receipts">Receipts</a></li>
	<li><a href="/admin/cart/settings">Config</a></li>
</ul>