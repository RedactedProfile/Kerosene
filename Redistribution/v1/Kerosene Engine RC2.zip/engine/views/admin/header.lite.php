<!DOCTYPE html>
<html>
	<head>
		<title><?=BaseAdmin::parseTitle($title);?></title>
		<?inc("jq");?>
		<?inc("css", "admin.styles");?>
	</head>
	<body class="login">
		
	