<?
class Debug {
	
	public static function dump($var) {
		echo "<pre>".print_r($var, true)."</pre>";
	}
	
	public static function log() {
		
	}
}