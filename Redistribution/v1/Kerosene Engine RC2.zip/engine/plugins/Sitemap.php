<?php
class Sitemap {
	
	public function __construct() {
		$this->GenerateSitemap();
	}
	
	public function GenerateSitemap() {
		
	}
	
}