<?php
class HelloDolly {
	
	private $lyrics = array(

			"Come gather 'round people",
			"Wherever you roam",
			"And admit that the waters",
			"Around you have grown",
			"And accept it that soon",
			"You'll be drenched to the bone",
			"If your time to you",
			"Is worth savin'",
			"Then you better start swimmin'",
			"Or you'll sink like a stone",
			"For the times they are a-changin'.",
			"",
			"Come writers and critics",
			"Who prophesize with your pen",
			"And keep your eyes wide",
			"The chance won't come again",
			"And don't speak too soon",
			"For the wheel's still in spin",
			"And there's no tellin' who",
			"That it's namin'",
			"For the loser now",
			"Will be later to win",
			"For the times they are a-changin'.",
			"",
			"Come senators, congressmen",
			"Please heed the call",
			"Don't stand in the doorway",
			"Don't block up the hall",
			"For he that gets hurt",
			"Will be he who has stalled",
			"There's a battle outside",
			"And it is ragin'",
			"It'll soon shake your windows",
			"And rattle your walls",
			"For the times they are a-changin'.",
			"",
			"Come mothers and fathers",
			"Throughout the land",
			"And don't criticize",
			"What you can't understand",
			"Your sons and your daughters",
			"Are beyond your command",
			"Your old road is",
			"Rapidly agin'",
			"Please get out of the new one",
			"If you can't lend your hand",
			"For the times they are a-changin'.",
			"",
			"The line it is drawn",
			"The curse it is cast",
			"The slow one now",
			"Will later be fast",
			"As the present now",
			"Will later be past",
			"The order is",
			"Rapidly fadin'",
			"And the first one now",
			"Will later be last",
			"For the times they are a-changin'"
			
	);
	
	public function __construct() {
		
	}
	
	public function generate() {
		return $this->lyrics[ array_rand($this->lyrics, 1) ];
	}
	
	public function __toString() {
		return $this->generate();
	}
	
}