		</div>
    <div style="clear: both;"></div>

    </div>
		<div id="footer-wrapper">
			<!--<span><strong><?=(string)new HelloDolly();?></strong> - <a href="http://www.navigatormm.com" target="_blank" title="Navigator Multimedia Inc"><em><strong><?=$Config->Engine->getName();?> <?=$Config->Engine->getVersion();?></strong></em> Content Management by Navigator Multimedia Inc</a></span>
			-->
			<span>
				<a href="http://www.com.com">
					<img src="/images/system/kerosene.png" />
				</a>
			</span>
		 	
		</div>
	</body>
</html>