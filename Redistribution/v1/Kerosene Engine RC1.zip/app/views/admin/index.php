<fieldset>
	<legend>Whats Happening Right Now</legend>
	
	Pages: <?=$count->TotalPages;?><br />
	Incomplete Pages: <?=$count->IncompletePages;?><br />
	Blog Posts: <?=$count->BlogPosts;?><br />
	<br />
	
	<?/*<img src="<?=$graphs->hits->render();?>" />*/?>
	
</fieldset>